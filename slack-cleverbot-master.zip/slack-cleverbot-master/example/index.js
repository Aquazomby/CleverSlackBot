import Bot from '../src';
import config from './config';

const mybot = Bot(config);
mybot.run();
